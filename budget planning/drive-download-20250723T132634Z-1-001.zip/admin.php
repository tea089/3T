<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Details</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
     <h2 class="h2">Accounts</h2>
    <table>
        <tr>
            <th>No.</th>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
        </tr>
        
        <?php
            // Connect to the database
            $servername = "localhost";
            $username = "root"; // Change to your MySQL username
            $password = ""; // Change to your MySQL password
            $dbname = "account";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query payments table
            $sql = "SELECT username, email, password FROM details";
            $result = $conn->query($sql);

            // Check for errors
            if (!$result) {
                die("Query failed: " . $conn->error);
            }
            // Counter for serial numbers
            $serialNumber = 1;

            // Check if there are any rows returned
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$serialNumber."</td>";
                    echo "<td>".$row["username"]."</td>";
                    echo "<td>".$row["email"]."</td>";
                    echo "<td>".$row["password"]."</td>";
                    echo "</tr>";
                    $serialNumber++; // Increment serial number for next row
                }
            } else {
                echo "<tr><td colspan='8'>No users found</td></tr>";
            }
            $conn->close();
        ?>

    </table>
    <a href="index.html"><button class="button" style="cursor: pointer;">Back</button></a>
</body>
</html>