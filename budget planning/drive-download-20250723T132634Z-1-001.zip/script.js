// ===== BACKGROUND IMAGE CYCLING ===== //
const backgrounds = [
    './img/index/background_spring.png',
    './img/index/background_summer.png',
    './img/index/background_fall.png',
    './img/index/background_winter.png'
];
let currentBgIndex = 0;
let isTransitioning = false;

function changeBackground() {
    if (isTransitioning) return;
    isTransitioning = true;
    currentBgIndex = (currentBgIndex + 1) % backgrounds.length;
    document.body.style.backgroundImage = `url('${backgrounds[currentBgIndex]}')`;
    setTimeout(() => isTransitioning = false, 2000);
}

// Click handlers for title elements
document.querySelector('.title-sign')?.addEventListener('click', function() {
    if (!isTransitioning) {
        this.classList.add('clicked');
        setTimeout(() => this.classList.remove('clicked'), 200);
        changeBackground();
    }
});

document.querySelector('.sticky-title')?.addEventListener('click', function() {
    if (!isTransitioning) {
        this.classList.add('clicked');
        setTimeout(() => this.classList.remove('clicked'), 200);
        changeBackground();
    }
});

// ===== STICKY NAVIGATION ===== //
const buttonRow = document.querySelector('.button-row');
const stickyNav = document.getElementById('stickyNav');

window.addEventListener('scroll', () => {
    const buttonRowBottom = buttonRow?.getBoundingClientRect().bottom || 0;
    stickyNav?.classList.toggle('visible', buttonRowBottom < 0);
});

// ===== BUTTON FUNCTIONALITY ===== //
document.querySelectorAll('.pixel-button').forEach(button => {
    button.addEventListener('click', (e) => {
        button.classList.add('clicked');
        setTimeout(() => button.classList.remove('clicked'), 200);

        switch(button.textContent.trim()) {
            case "SIGN UP": window.location.href = "signUp.html"; break;
            case "REVIEW US": window.location.href = "review.html"; break;
            case "FAQ": window.location.href = "faq.html"; break;
            case "LOG IN": window.location.href = "login.html"; break;
            case "HOME": window.location.href = "homepage.html"; break;
        }
    });
});

// ===== SCROLL TO TOP/BOTTOM ===== //
document.querySelectorAll('.back-to-top').forEach(button => {
    button.addEventListener('click', () => {
        button.classList.add('clicked');
        setTimeout(() => button.classList.remove('clicked'), 200);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});

document.querySelectorAll('.down-to-bottom').forEach(button => {
    button.addEventListener('click', () => {
        button.classList.add('clicked');
        setTimeout(() => button.classList.remove('clicked'), 200);
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    });
});

// ===== SETTINGS SIDEBAR ===== //
const settingsButton = document.querySelector('.settings-button');
const overlay = document.getElementById('overlay');
const rightSidebar = document.getElementById('rightSidebar');
const closeSidebar = document.getElementById('closeSidebar');

settingsButton?.addEventListener('click', (e) => {
    e.preventDefault();
    overlay.classList.add('active');
    rightSidebar.classList.add('active');
    document.body.style.overflow = 'hidden';
});

closeSidebar?.addEventListener('click', () => {
    overlay.classList.remove('active');
    rightSidebar.classList.remove('active');
    document.body.style.overflow = '';
});

overlay?.addEventListener('click', () => {
    overlay.classList.remove('active');
    rightSidebar.classList.remove('active');
    document.body.style.overflow = '';
});

// ===== CUSTOM SCROLLBAR ===== //
const scrollbarThumb = document.querySelector('.scrollbar-thumb');
const scrollbarTrack = document.querySelector('.scrollbar-track');
const scrollUp = document.querySelector('.scroll-up');
const scrollDown = document.querySelector('.scroll-down');
let isDragging = false;

// Update thumb size/position
function updateThumb() {
    const { scrollHeight, clientHeight } = document.documentElement;
    const thumbHeight = Math.max(20, (clientHeight / scrollHeight) * 100);
    scrollbarThumb.style.height = `${thumbHeight}%`;

    const scrollPosition = window.scrollY;
    const scrollableHeight = scrollHeight - clientHeight;
    const thumbPosition = (scrollPosition / scrollableHeight) * 100;
    scrollbarThumb.style.top = `${thumbPosition}%`;
}

// Scroll buttons
scrollUp?.addEventListener('click', () => {
    window.scrollBy(0, -100);
    updateThumb();
});

scrollDown?.addEventListener('click', () => {
    window.scrollBy(0, 100);
    updateThumb();
});

// Thumb dragging
scrollbarThumb?.addEventListener('mousedown', (e) => {
    isDragging = true;
    e.preventDefault();
});

document.addEventListener('mousemove', (e) => {
    if (!isDragging || !scrollbarTrack) return;
    
    const trackRect = scrollbarTrack.getBoundingClientRect();
    const thumbY = e.clientY - trackRect.top;
    const thumbPosition = Math.min(100, Math.max(0, (thumbY / trackRect.height) * 100));
    const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo(0, (thumbPosition / 100) * scrollableHeight);
});

document.addEventListener('mouseup', () => isDragging = false);

// Track click
scrollbarTrack?.addEventListener('click', (e) => {
    if (e.target === scrollbarThumb) return;
    const trackRect = scrollbarTrack.getBoundingClientRect();
    const clickY = e.clientY - trackRect.top;
    const thumbHeight = scrollbarThumb.offsetHeight;
    const thumbPosition = Math.min(100, Math.max(0, (clickY / trackRect.height) * 100 - (thumbHeight / 2)));
    const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo(0, (thumbPosition / 100) * scrollableHeight);
});

// Mouse wheel (critical fix)
document.addEventListener('wheel', (e) => {
    window.scrollBy(0, e.deltaY);
    updateThumb();
}, { passive: true }); // 'passive: true' improves performance

// Initialize
updateThumb();
window.addEventListener('resize', updateThumb);
window.addEventListener('scroll', updateThumb);

// ===== BACKGROUND SELECTION IN SETTINGS ===== //
document.querySelectorAll('.bg-option').forEach(option => {
    option.addEventListener('click', function() {
        // Remove active border from all options
        document.querySelectorAll('.bg-option').forEach(opt => {
            opt.style.border = 'none';
        });
        
        // Add border to selected option
        this.style.border = '2px solid #c9a66b';
        
        // Change background image
        const bgImage = this.getAttribute('data-bg');
        document.body.style.backgroundImage = `url('${bgImage}')`;
        
        // Optional: Save to localStorage to remember preference
        localStorage.setItem('selectedBackground', bgImage);
    });
});

// Load saved background on page load
window.addEventListener('DOMContentLoaded', () => {
    const savedBg = localStorage.getItem('selectedBackground');
    if (savedBg) {
        document.body.style.backgroundImage = `url('${savedBg}')`;
        
        // Highlight the saved option in settings
        document.querySelectorAll('.bg-option').forEach(option => {
            if (option.getAttribute('data-bg') === savedBg) {
                option.style.border = '2px solid #c9a66b';
            }
        });
    }
});