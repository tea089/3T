<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "account";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';

    // Insert data into database
    $sql = "INSERT INTO details (username, email, password )
    VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {

        echo "<script>window.setTimeout(function(){ window.location.href = 'homepage.html'; }, 1000);</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
?>